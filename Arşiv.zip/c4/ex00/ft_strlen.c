/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/15 08:46:45 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/15 08:49:55 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	index;
	int	lenght;

	index = 0;
	lenght = 0;
	while (str[index] != '\0')
	{
		lenght += 1;
		index += 1;
	}
	return (lenght);
}
