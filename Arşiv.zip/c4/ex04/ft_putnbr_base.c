/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/22 15:50:47 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/22 15:50:49 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

void	ft_putstr_reverse(char *str)
{
	int	index;

	index = ft_strlen(str) - 1;
	while (index >= 0)
	{
		write(1, &str[index], 1);
		index--;
	}
}

int	base_check(char *base)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (base[0] == '\0' || base[1] == '\0')
		return (0);
	while (base[i])
	{
		j = i + 1;
		if (base[i] == '+' || base[i] == '-')
			return (0);
		if (base[i] < 32 || base[i] > 126)
			return (0);
		while (base[j])
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	str_add(char *str, char c, int i)
{
	str[i] = c;
	str[i + 1] = '\0';
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		sign;
	int		lenght;
	int		i;
	long	nbr_l;
	char	ch_c[64];

	i = 0;
	sign = 1;
	lenght = ft_strlen(base);
	nbr_l = nbr;
	if (base_check(base) == 0)
		return ;
	if (nbr < 0)
	{
		write(1, "-", 1);
		nbr_l *= -1;
	}
	while (nbr_l > 0)
	{
		str_add(ch_c, base[nbr_l % lenght], i);
		i++;
		nbr_l /= lenght;
	}
	ft_putstr_reverse(ch_c);
}
