/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/30 09:57:45 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/30 09:57:47 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	len;
	int	i;
	int	*buf;

	if (min >= max)
	{
		range = NULL;
		return (0);
	}
	len = max - min;
	buf = (int *)malloc(len * sizeof(int));
	if (buf == NULL)
	{
		range = NULL;
		return (-1);
	}
	i = 0;
	while (i < len)
	{
		buf[i] = min;
		i++;
		min++;
	}
	*range = buf;
	return (i);
}
