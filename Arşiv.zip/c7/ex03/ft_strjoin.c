/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/26 10:48:03 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/30 09:57:55 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strstrlen(int size, char **strs)
{
	int	i;
	int	j;
	int	len;

	i = 0;
	j = 0;
	len = 0;
	while (i < size)
	{
		while (strs[i][j] != '\0')
		{
			j++;
			len++;
		}
		i++;
		j = 0;
	}
	len = len + (size - 1);
	return (len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	int		j;
	int		l;
	char	*arr;

	i = 0;
	j = 0;
	arr = (char *)malloc(ft_strstrlen(size, strs) * sizeof(char));
	l = 0;
	while (i < size)
	{
		while (strs[i][j] != '\0')
		{
			arr[l] = strs[i][j];
			l++;
			j++;
		}
		if (l != ft_strstrlen(size, strs))
			arr[l] = *sep;
		l++;
		i++;
		j = 0;
	}
	return (arr);
}
