/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/16 17:19:12 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/17 10:58:45 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	if (str[i] >= 'a' && str[i] <= 'z')
		str[i] -= 32;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		if (!(str[i - 1] <= '9' && str[i - 1] >= '0'))
			if (!(str[i - 1] <= 'Z' && str[i - 1] >= 'A'))
				if (!(str[i - 1] <= 'z' && str[i - 1] >= 'a'))
					if (str[i] >= 'a' && str[i] <= 'z')
						str[i] -= 32;
		i++;
	}
	return (str);
}
