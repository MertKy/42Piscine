/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/24 18:37:19 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/24 18:37:20 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	result;
	int	temp;

	result = 1;
	temp = 0;
	if (power < 0)
		return (0);
	if (nb == 0 && power == 0)
		return (1);
	while (temp < power)
	{
		result *= nb;
		temp++;
	}
	return (result);
}
