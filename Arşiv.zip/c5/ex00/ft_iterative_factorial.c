/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/24 18:36:55 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/24 18:36:57 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int		result;
	long	result_l;

	result_l = 1;
	if (nb < 0)
		return (0);
	while (nb > 0)
	{
		result_l *= nb;
		nb--;
	}
	result = result_l;
	return (result);
}
