git log --pretty="%H" | head -n5
