/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bakdogan <bakdogan@student.42istanbul.c    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/15 16:07:37 by bakdogan          #+#    #+#             */
/*   Updated: 2023/07/15 16:07:47 by bakdogan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	one(int *i, int *k, int *x)
{
	if (*k == 1 || *k == *x)
	{
		ft_putchar('A');
		if (*k == *x)
		{
			*i = *i + 1;
			*k = 0;
			ft_putchar('\n');
		}
		*k = *k + 1;
	}
	else
	{
		ft_putchar('B');
		*k = *k + 1;
	}
}

void	two(int *i, int *k, int *x)
{
	if (*k == 1 || *k == *x)
	{
		ft_putchar('C');
		if (*k == *x)
		{
			*i = *i + 1;
			ft_putchar('\n');
		}
		*k = *k + 1;
	}
	else
	{
		ft_putchar('B');
		*k = *k + 1;
	}
}

void	three(int *i, int *k, int *x)
{
	if (*k == 1 || *k == *x)
	{
		ft_putchar('B');
		if (*k == *x)
		{
			*i = *i + 1;
			*k = 0;
			ft_putchar('\n');
		}
		*k = *k + 1;
	}
	else
	{
		ft_putchar(' ');
		*k = *k + 1;
	}
}

void	rush(int x, int y)
{
	int	i;
	int	k;

	i = 1;
	k = 1;
	while (i <= y && k <= x)
	{
		if (i == 1)
		{
			one(&i, &k, &x);
		}
		else if (i == y)
		{
			two(&i, &k, &x);
		}
		else
		{
			three(&i, &k, &x);
		}
	}
}
