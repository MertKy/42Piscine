/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mertkaya <mertkaya@student.42istanbul.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/13 09:30:00 by mertkaya          #+#    #+#             */
/*   Updated: 2023/07/13 09:41:24 by mertkaya         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_check(int arr[], int size)
{
	int	i;

	i = size - 1;
	while (i >= 1)
	{
		if (arr[i] != arr[i - 1] + 1)
		{
			return (i - 1);
		}
		i--;
	}
	return (-1);
}

void	ft_update(int arr[], int size, int index)
{
	arr[index]++;
	index++;
	while (index <= size - 1)
	{
		arr[index] = arr[index - 1] + 1;
		index++;
	}
}

void	ft_print(int arr[], int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		ft_putchar(arr[i] + '0');
		i++;
	}
	if (arr[0] != 10 - size)
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	ft_print_combn(int n)
{
	int	arr[10];
	int	i;

	i = 0;
	while (i < n)
	{
		arr[i] = i;
		i++;
	}
	while (arr[0] <= 10 - n)
	{
		while (arr[n - 1] != 9)
		{
			ft_print(arr, n);
			arr[n - 1]++;
		}
		ft_print(arr, n);
		if (arr[n - 1] == 9)
		{
			if (ft_check(arr, n) == -1)
				break ;
			else
				ft_update(arr, n, ft_check(arr, n));
		}
	}
}
